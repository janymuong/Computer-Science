import time
import random
import multiprocessing as mp


def matrix_vector_sequential(A, x):
    """Sequential matrix-vector multiplication: y = A * x"""
    n = len(x)
    y = [0.0] * n
    for i in range(n):
        for j in range(n):
            y[i] += A[i][j] * x[j]
    return y


def worker_column_wise(task_queue, result_queue):
    """Worker process: receives column chunks, computes partial dot products, returns results."""
    while True:
        task = task_queue.get()
        if task is None:  # Poison pill — shut down
            break

        worker_id, A_cols, x_segment = task
        n = len(A_cols)
        partial_y = [0.0] * n

        for i in range(n):
            for j in range(len(x_segment)):
                partial_y[i] += A_cols[i][j] * x_segment[j]

        result_queue.put((worker_id, partial_y))


def matrix_vector_parallel_colwise(A, x, num_processes):
    """
    Parallel matrix-vector multiplication using column-wise decomposition.
    Splits matrix columns across workers, collects partial results, then reduces.
    """
    n = len(x)

    # Distribute columns as evenly as possible
    base_chunk = n // num_processes
    remainder = n % num_processes

    col_starts, col_ends = [], []
    start = 0
    for p in range(num_processes):
        chunk = base_chunk + (1 if p < remainder else 0)
        col_starts.append(start)
        col_ends.append(start + chunk)
        start += chunk

    task_queue = mp.Queue()
    result_queue = mp.Queue()

    # Spawn workers
    processes = []
    for _ in range(num_processes):
        p = mp.Process(target=worker_column_wise, args=(task_queue, result_queue))
        p.start()
        processes.append(p)

    # Send each worker its column slice and matching x segment
    for worker_id in range(num_processes):
        c_start, c_end = col_starts[worker_id], col_ends[worker_id]
        A_cols = [row[c_start:c_end] for row in A]
        x_segment = x[c_start:c_end]
        task_queue.put((worker_id, A_cols, x_segment))

    # Collect partial results
    partial_results = [None] * num_processes
    for _ in range(num_processes):
        worker_id, partial_y = result_queue.get()
        partial_results[worker_id] = partial_y

    # Shut down workers
    for _ in range(num_processes):
        task_queue.put(None)
    for p in processes:
        p.join()

    # Reduction: sum all partial vectors
    y = [0.0] * n
    for partial_y in partial_results:
        for i in range(n):
            y[i] += partial_y[i]

    return y


def verify_correctness():
    print("=== CORRECTNESS VERIFICATION ===")

    A = [
        [2, 1, 0],
        [1, 3, 1],
        [0, 1, 2],
    ]
    x = [3, 2, 1]
    expected = [8, 10, 4]

    print(f"Sequential Result: {matrix_vector_sequential(A, x)}")

    for nproc in [2, 3]:
        result = matrix_vector_parallel_colwise(A, x, num_processes=nproc)
        passed = all(abs(result[i] - expected[i]) < 1e-9 for i in range(len(expected)))
        print(f"{nproc} processes → {result}  PASSED: {passed}")

    print()


def generate_matrix(n):
    return [[random.random() for _ in range(n)] for _ in range(n)]


def generate_vector(n):
    return [random.random() for _ in range(n)]


def benchmark(sizes, process_counts, runs=3):
    print("=== BENCHMARKING ===")
    print(f"Averaging over {runs} runs\n")

    header = f"{'Size':>6} | {'Mode':>12} | {'Processes':>9} | {'Avg Time (s)':>14}"
    print(header)
    print("-" * len(header))

    for n in sizes:
        A = generate_matrix(n)
        x = generate_vector(n)

        seq_times = []
        for _ in range(runs):
            start = time.perf_counter()
            matrix_vector_sequential(A, x)
            seq_times.append(time.perf_counter() - start)

        print(f"{n:>6} | {'Sequential':>12} | {'-':>9} | {sum(seq_times)/runs:>14.6f}")

        for nproc in process_counts:
            par_times = []
            for _ in range(runs):
                start = time.perf_counter()
                matrix_vector_parallel_colwise(A, x, num_processes=nproc)
                par_times.append(time.perf_counter() - start)

            print(f"{n:>6} | {'Parallel':>12} | {nproc:>9} | {sum(par_times)/runs:>14.6f}")

    print()


if __name__ == "__main__":
    verify_correctness()
    benchmark(
        sizes=[100, 500, 1000, 2000],
        process_counts=[2, 4, 8],
        runs=3,
    )